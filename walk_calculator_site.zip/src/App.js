import React, { useState } from "react";

const CHECKOUT_URL = "https://seu-checkout-aqui.com/ebook-alimentacao-saudavel";

export default function App() {
  const [name, setName] = useState("");
  const [weight, setWeight] = useState(80);
  const [height, setHeight] = useState(175);
  const [age, setAge] = useState(30);
  const [sex, setSex] = useState("male");
  const [showResult, setShowResult] = useState(false);
  const [result, setResult] = useState(null);

  function calculateIdealWeight(heightCm) {
    const heightM = heightCm / 100;
    return 22 * heightM * heightM;
  }

  function caloriesPerMinuteWalking(weightKg, met = 4.0) {
    return (met * 3.5 * weightKg) / 200;
  }

  function handleCalculate(e) {
    e.preventDefault();
    const pesoAtual = Number(weight);
    const altura = Number(height);
    const pesoIdeal = calculateIdealWeight(altura);
    const pesoAperder = Math.max(0, pesoAtual - pesoIdeal);
    const kcalPorKg = 7700;
    const metaPerdaKgPorSemana = 0.5;
    const deficitSemanal = metaPerdaKgPorSemana * kcalPorKg;
    const deficitDiario = deficitSemanal / 7;
    const metWalking = 4.0;
    const kcalPorMin = caloriesPerMinuteWalking(pesoAtual, metWalking);
    const minutosPorDia = Math.ceil(deficitDiario / kcalPorMin);
    const semanasNecessarias = pesoAperder > 0 ? Math.ceil((pesoAperder / metaPerdaKgPorSemana)) : 0;
    const diasNecessarios = semanasNecessarias * 7;

    setResult({
      pesoIdeal: Number(pesoIdeal.toFixed(1)),
      pesoAperder: Number(pesoAperder.toFixed(1)),
      deficitDiario: Number(deficitDiario.toFixed(0)),
      minutosPorDia,
      metWalking,
      semanasNecessarias,
      diasNecessarios,
    });
    setShowResult(true);
  }

  return (
    <div style={{ fontFamily: "Arial", padding: 20 }}>
      <h1>Calculadora de Caminhada</h1>
      <p>Informe seus dados para estimar o quanto caminhar por dia para chegar ao peso ideal.</p>
      <form onSubmit={handleCalculate}>
        <input placeholder="Peso (kg)" type="number" value={weight} onChange={(e)=>setWeight(e.target.value)} />
        <input placeholder="Altura (cm)" type="number" value={height} onChange={(e)=>setHeight(e.target.value)} />
        <input placeholder="Idade" type="number" value={age} onChange={(e)=>setAge(e.target.value)} />
        <button type="submit">Calcular</button>
      </form>

      {showResult && result && (
        <div>
          <h2>Resultado</h2>
          <p>Peso ideal: {result.pesoIdeal} kg</p>
          <p>Peso a perder: {result.pesoAperder} kg</p>
          <p>Minutos de caminhada por dia: {result.minutosPorDia} min</p>
          <p>Tempo estimado: {result.semanasNecessarias} semanas</p>
          <a href={CHECKOUT_URL} target="_blank" rel="noreferrer">Compre o ebook de alimentação saudável</a>
        </div>
      )}
    </div>
  );
}
